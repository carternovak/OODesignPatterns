/*
 * MyErrorHandler.h
 *
 *  Created on: 12 avr. 2014
 *      Author: FrancisANDRE
 */

#ifndef MYERRORHANDLER_H_
#define MYERRORHANDLER_H_
#include "ErrorHandler.h"

namespace @NAMESPACE@ {

class MyErrorHandler : public ErrorHandler {
public:
	MyErrorHandler();
	virtual ~MyErrorHandler();
};

} /* namespace @NAMESPACE@ */

#endif /* MYERRORHANDLER_H_ */
