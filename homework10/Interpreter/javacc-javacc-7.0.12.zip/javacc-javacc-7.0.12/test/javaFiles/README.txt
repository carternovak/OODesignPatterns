Tests the creation of the near bolier-plate Java Files, created by
JavaFiles.java. It checks that files are recreated automatically if
they are unchanged, but not modified if they have changed. It also
checks that incompatible options are handled correctly.

See also "javaFileGeneration" test, which checks the contents of the files.
